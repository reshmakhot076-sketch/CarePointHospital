package com.example.carepointhospital;

import android.app.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.location.*;
import android.graphics.Color;
import android.provider.Settings;
import android.text.InputType;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int teal=Color.rgb(0,121,107), coral=Color.rgb(255,111,97), dark=Color.rgb(38,50,56);
    private static final int LOCATION_PERMISSION_REQUEST=501;
    private LinearLayout departments, doctors;
    private BookingDb bookingDb;
    private String patientPhone="", patientName="", loggedDoctor="";
    private final String[] deptNames={"Cardiology","Dentistry","Neurology","Orthopedics","Radiology"};
    private final String[] doctorNames={"Dr. Sarah Thompson","Dr. Michael Roberts","Dr. Jessica Wyne","Dr. David Johnson","Dr. Richard Lee"};
    private final String[] doctorDepts={"Cardiology","Dentistry","Neurology","Orthopedics","Radiology"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        bookingDb=new BookingDb(this);
        findViewById(R.id.findNearby).setOnClickListener(v->findNearbyHospitals());
        findViewById(R.id.patientBookings).setOnClickListener(v->patientLogin());
        findViewById(R.id.doctorBookings).setOnClickListener(v->doctorLogin());
    }

    private TextView label(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(dark);v.setPadding(12,10,12,10);return v;}
    private GradientDrawable rounded(int color,int radius){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius*getResources().getDisplayMetrics().density);return d;}
    private void buildDepartments(){
        for(String dept:deptNames){TextView item=new TextView(this);item.setText(dept);item.setTextSize(15);item.setTextColor(Color.WHITE);item.setTypeface(null,1);item.setGravity(Gravity.CENTER);item.setMinHeight(dp(48));item.setPadding(16,10,16,10);item.setBackground(rounded(teal,8));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);departments.addView(item,lp);item.setOnClickListener(v->chooseDoctorForDepartment(dept));}
    }
    private void buildDoctors(){
        for(int i=0;i<doctorNames.length;i++){final int index=i;LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(16,16,16,16);card.setBackground(rounded(Color.WHITE,12));card.setElevation(dp(2));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,8,0,10);
            int image=getResources().getIdentifier(doctorFile(i),"drawable",getPackageName());if(image!=0){ImageView im=new ImageView(this);im.setImageResource(image);im.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(im,new LinearLayout.LayoutParams(dp(76),dp(76)));}
            TextView n=label(doctorNames[i],18);n.setTextColor(teal);n.setTypeface(null,1);n.setGravity(Gravity.CENTER);card.addView(n);TextView sp=label(doctorDepts[i]+" Specialist",14);sp.setGravity(Gravity.CENTER);card.addView(sp);
            Button book=new Button(this);book.setText("Book Appointment");book.setAllCaps(false);book.setOnClickListener(v->showAppointment(doctorNames[index],doctorDepts[index]));card.addView(book,new LinearLayout.LayoutParams(-1,-2));doctors.addView(card,cp);
        }
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private String doctorFile(int i){return new String[]{"dr_sarah_thompson","dr_michael_roberts","dr_jessica_wyne","dr_david_johnson","dr_richard_lee"}[i];}
    private void chooseDoctorForDepartment(String dept){ArrayList<String> names=new ArrayList<>();ArrayList<Integer> indexes=new ArrayList<>();for(int i=0;i<doctorNames.length;i++)if(doctorDepts[i].equals(dept)){names.add(doctorNames[i]);indexes.add(i);}if(names.isEmpty()){toast("No doctors available in this department.");return;}String[] a=names.toArray(new String[0]);new AlertDialog.Builder(this).setTitle(dept+" – Select Doctor").setItems(a,(d,w)->showAppointment(a[w],dept)).setNegativeButton("Close",null).show();}

    private void showAppointment(String doctor,String dept){
        if(patientPhone.isEmpty()){new AlertDialog.Builder(this).setTitle("Patient login required").setMessage("Please register or log in before booking an appointment.").setPositiveButton("Login",(d,w)->patientLogin()).setNegativeButton("Cancel",null).show();return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(20),0,dp(20),0);
        EditText name=field("Patient name",InputType.TYPE_CLASS_TEXT);name.setText(patientName);name.setEnabled(false);EditText phone=field("Phone number",InputType.TYPE_CLASS_PHONE);phone.setText(patientPhone);phone.setEnabled(false);EditText date=field("Appointment date (yyyy-MM-dd)",InputType.TYPE_CLASS_DATETIME);EditText time=field("Appointment time (HH:mm, 24-hour)",InputType.TYPE_CLASS_DATETIME);EditText symptoms=field("Symptoms / reason for visit",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(name);box.addView(phone);box.addView(date);box.addView(time);box.addView(symptoms);
        new AlertDialog.Builder(this).setTitle("Book Appointment").setMessage(doctor+" • "+dept).setView(box).setPositiveButton("Submit request",(d,w)->{
            String n=name.getText().toString().trim(),p=phone.getText().toString().trim(),dt=date.getText().toString().trim(),tm=time.getText().toString().trim(),sy=symptoms.getText().toString().trim();
            if(n.isEmpty()||p.isEmpty()||dt.isEmpty()||tm.isEmpty()){toast("Enter patient name, phone, date and time.");return;}
            Date selectedDate; try{SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);sdf.setLenient(false);selectedDate=sdf.parse(dt+" "+tm);if(selectedDate==null)throw new Exception();}catch(Exception e){toast("Use date yyyy-MM-dd and time HH:mm (24-hour). Example: 2026-11-06 and 10:30.");return;}
            if(!selectedDate.after(new Date())){toast("Please choose a future date and time. Today's past or current time is not allowed.");return;}
            if(bookingDb.isSlotTaken(doctor,dt,tm)){toast("This doctor already has an appointment at that time. Please choose another slot.");return;}
            if(bookingDb.isPatientSlotTaken(p,dt,tm)){toast("You already have an appointment at this date and time. Please choose another time.");return;}
            long id=bookingDb.addBooking(n,p,doctor,dept,dt,tm,sy);
            if(id>0){patientPhone=p;new AlertDialog.Builder(this).setTitle("Appointment request submitted").setMessage("Booking ID: "+id+"\nStatus: Pending doctor confirmation\nA confirmation message will appear in My Appointments.").setPositiveButton("OK",null).show();}else toast("Unable to save appointment. The selected time may have just been booked.");
        }).setNegativeButton("Cancel",null).show();
    }
    private EditText field(String hint,int type){EditText e=new EditText(this);e.setHint(hint);e.setInputType(type);return e;}
    private void patientLogin(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(20),0,dp(20),0);
        EditText email=field("Registered email address",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);EditText pass=field("Password",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(email);box.addView(pass);
        new AlertDialog.Builder(this).setTitle("Patient Login").setView(box)
            .setPositiveButton("Login",(d,w)->{String e=email.getText().toString().trim(),pw=pass.getText().toString();if(e.isEmpty()||pw.isEmpty()){toast("Enter email and password.");return;}Cursor c=bookingDb.loginPatient(e,passwordHash(pw));if(c!=null&&c.moveToFirst()){patientName=c.getString(c.getColumnIndexOrThrow("name"));patientPhone=c.getString(c.getColumnIndexOrThrow("phone"));c.close();toast("Welcome, "+patientName);patientDashboard();}else{if(c!=null)c.close();toast("Invalid email or password. Please register first.");}})
            .setNeutralButton("Register here",(d,w)->patientRegister()).setNegativeButton("Cancel",null).show();
    }
    private void patientDashboard(){
        String[] options={"Book an Appointment", "My Appointments", "Logout"};
        new AlertDialog.Builder(this).setTitle("Welcome, "+patientName+" – Patient Dashboard")
            .setItems(options,(dialog,which)->{
                if(which==0) showDepartmentPicker();
                else if(which==1) showPatientBookings(patientPhone);
                else { patientPhone=""; patientName=""; toast("Logged out."); }
            }).setCancelable(false).show();
    }
    private void showDepartmentPicker(){
        new AlertDialog.Builder(this).setTitle("Choose a Department")
            .setItems(deptNames,(d,which)->chooseDoctorForDepartment(deptNames[which]))
            .setNegativeButton("Back",(d,w)->patientDashboard()).show();
    }

    private void patientRegister(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(20),0,dp(20),0);
        EditText name=field("Full name",InputType.TYPE_CLASS_TEXT);EditText email=field("Email address",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);EditText phone=field("Mobile number",InputType.TYPE_CLASS_PHONE);EditText age=field("Age",InputType.TYPE_CLASS_NUMBER);EditText gender=field("Gender",InputType.TYPE_CLASS_TEXT);EditText pass=field("Create password",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);EditText confirm=field("Confirm password",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(name);box.addView(email);box.addView(phone);box.addView(age);box.addView(gender);box.addView(pass);box.addView(confirm);
        new AlertDialog.Builder(this).setTitle("Patient Registration").setMessage("Create your patient account").setView(box).setPositiveButton("Register",(d,w)->{
            String n=name.getText().toString().trim(),e=email.getText().toString().trim().toLowerCase(Locale.ROOT),p=phone.getText().toString().trim(),a=age.getText().toString().trim(),g=gender.getText().toString().trim(),pw=pass.getText().toString(),cp=confirm.getText().toString();
            if(n.isEmpty()||e.isEmpty()||p.isEmpty()||pw.isEmpty()||cp.isEmpty()){toast("Please fill name, email, phone and password fields.");return;}
            if(!Patterns.EMAIL_ADDRESS.matcher(e).matches()){toast("Enter a valid email address.");return;}
            if(pw.length()<6){toast("Password must contain at least 6 characters.");return;}
            if(!pw.equals(cp)){toast("Passwords do not match.");return;}
            if(bookingDb.registerPatient(n,e,p,a,g,passwordHash(pw))){patientName=n;patientPhone=p;toast("Registration successful. You are now logged in.");patientDashboard();}else toast("Email or phone number is already registered.");
        }).setNegativeButton("Cancel",null).show();
    }
    private String passwordHash(String value){try{
        MessageDigest md= MessageDigest.getInstance("SHA-256");byte[] bytes=md.digest(value.getBytes("UTF-8"));StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(Locale.US,"%02x",b));return out.toString();}catch(Exception e){return value;}}
    private void doctorLogin(){String[] accounts=new String[doctorNames.length];for(int i=0;i<accounts.length;i++)accounts[i]=doctorNames[i]+" ("+doctorDepts[i]+")";new AlertDialog.Builder(this).setTitle("Doctor Login – Select account").setItems(accounts,(d,which)->{EditText pass=field("Doctor password",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);new AlertDialog.Builder(this).setTitle("Doctor Login").setMessage("Sign in to manage your patient appointments.").setView(pass).setPositiveButton("Login",(dd,ww)->{if("doctor123".equals(pass.getText().toString())){loggedDoctor=doctorNames[which];showDoctorBookings(loggedDoctor);}else toast("Incorrect doctor password.");}).setNegativeButton("Cancel",null).show();}).setNegativeButton("Cancel",null).show();}
    private void showPatientBookings(String phone){Cursor c=bookingDb.getPatientBookings(phone);showBookingList(c,false,phone);}
    private void showDoctorBookings(String doctor){
        Cursor c=bookingDb.getDoctorBookings(doctor);
        showBookingList(c,true,doctor);
    }
    private void showBookingList(Cursor c,boolean doctorView,String owner){
        if(c==null||c.getCount()==0){
            if(c!=null)c.close();
            new AlertDialog.Builder(this)
                .setTitle(doctorView?"Doctor Appointments":"My Appointments")
                .setMessage("No appointments found.")
                .setPositiveButton("OK",null)
                .show();
            return;
        }
        ArrayList<Long> ids=new ArrayList<>();
        ArrayList<String> rows=new ArrayList<>();
        while(c.moveToNext()){
            long id=c.getLong(c.getColumnIndexOrThrow("id"));
            ids.add(id);
            String status=c.getString(c.getColumnIndexOrThrow("status"));
            String statusEmoji=status.equals("Confirmed")?"✅ Confirmed":status.equals("Rejected")?"❌ Rejected":status.equals("Cancelled")?"🚫 Cancelled":"⏳ Pending Confirmation";
            if(doctorView){
                rows.add("#"+id+"  "+c.getString(c.getColumnIndexOrThrow("patient"))+"\n"+c.getString(c.getColumnIndexOrThrow("department"))+" • "+c.getString(c.getColumnIndexOrThrow("doctor"))+"\n"+c.getString(c.getColumnIndexOrThrow("appointment_date"))+" at "+c.getString(c.getColumnIndexOrThrow("appointment_time"))+"\nStatus: "+statusEmoji);
            }else{
                rows.add("#"+id+" • "+c.getString(c.getColumnIndexOrThrow("doctor"))+"\nDept: "+c.getString(c.getColumnIndexOrThrow("department"))+"\nDate: "+c.getString(c.getColumnIndexOrThrow("appointment_date"))+" at "+c.getString(c.getColumnIndexOrThrow("appointment_time"))+"\nStatus: "+statusEmoji);
            }
        }
        c.close();
        new AlertDialog.Builder(this)
            .setTitle(doctorView?"Appointments – "+owner:"My Appointments ("+owner+")")
            .setItems(rows.toArray(new String[0]),(d,w)->bookingDetails(ids.get(w),doctorView,owner))
            .setNegativeButton("Close",null)
            .show();
    }
    private void bookingDetails(long id,boolean doctorView,String owner){
        Cursor c=bookingDb.getBooking(id);
        if(c==null||!c.moveToFirst()){
            if(c!=null)c.close();
            return;
        }
        String patient=c.getString(c.getColumnIndexOrThrow("patient")),
               phone=c.getString(c.getColumnIndexOrThrow("phone")),
               doctor=c.getString(c.getColumnIndexOrThrow("doctor")),
               dept=c.getString(c.getColumnIndexOrThrow("department")),
               date=c.getString(c.getColumnIndexOrThrow("appointment_date")),
               time=c.getString(c.getColumnIndexOrThrow("appointment_time")),
               sym=c.getString(c.getColumnIndexOrThrow("symptoms")),
               status=c.getString(c.getColumnIndexOrThrow("status")),
               medicine=c.getString(c.getColumnIndexOrThrow("medicine")),
               dose=c.getString(c.getColumnIndexOrThrow("dosage")),
               frequency=c.getString(c.getColumnIndexOrThrow("frequency")),
               duration=c.getString(c.getColumnIndexOrThrow("duration")),
               instructions=c.getString(c.getColumnIndexOrThrow("instructions")),
               message=c.getString(c.getColumnIndexOrThrow("notification"));
        c.close();
        
        String statusEmoji=status.equals("Confirmed")?"✅ Confirmed":status.equals("Rejected")?"❌ Rejected":status.equals("Cancelled")?"🚫 Cancelled":"⏳ Pending Confirmation";
        String detail="Patient: "+patient+"\nPhone: "+phone+"\nDepartment: "+dept+"\nDoctor: "+doctor+"\nDate: "+date+"\nTime: "+time+"\nSymptoms: "+sym+"\nStatus: "+statusEmoji+"\n\nDoctor Message / Status Update:\n"+message;
        if(!doctorView&&!medicine.isEmpty()){
            detail+="\n\nPrescribed Medicine / Tablet:\n• Medicine: "+medicine+"\n• Dosage: "+dose+"\n• Frequency: "+frequency+"\n• Duration: "+duration+"\n• Instructions: "+instructions;
        }
        
        ArrayList<String> actions=new ArrayList<>();
        if(doctorView){
            if(status.equals("Pending")){
                actions.add("Confirm appointment");
                actions.add("Cancel appointment");
            }else if(status.equals("Confirmed")){
                actions.add("Cancel appointment");
            }
            if(!status.equals("Cancelled")&&!status.equals("Rejected")){
                actions.add("Suggest medicine / tablet");
            }
        }else if(!status.equals("Cancelled")&&!status.equals("Rejected")&&!status.equals("Completed")){
            actions.add("Cancel appointment");
        }
        
        ScrollView scroll=new ScrollView(this);
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(12), dp(20), dp(12));
        
        TextView tv=new TextView(this);
        tv.setText(detail);
        tv.setTextSize(15);
        tv.setTextColor(dark);
        box.addView(tv);
        
        if(!actions.isEmpty()){
            View divider=new View(this);
            divider.setBackgroundColor(Color.LTGRAY);
            LinearLayout.LayoutParams dpLp = new LinearLayout.LayoutParams(-1, dp(1));
            dpLp.setMargins(0, dp(14), 0, dp(14));
            box.addView(divider, dpLp);
            
            for(String action : actions){
                Button btn = new Button(this);
                btn.setText(action);
                btn.setAllCaps(false);
                int btnColor = action.contains("Confirm") ? teal : action.contains("Reject") || action.contains("Cancel") ? coral : teal;
                btn.setBackground(rounded(btnColor, 8));
                btn.setTextColor(Color.WHITE);
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
                bp.setMargins(0, dp(6), 0, dp(6));
                btn.setOnClickListener(v -> {
                    if(action.equals("Confirm appointment")){
                        bookingDb.setStatus(id,"Confirmed","Your appointment with "+doctor+" on "+date+" at "+time+" is confirmed.");
                        toast("Appointment confirmed. Patient notification saved.");
                        bookingDetails(id,true,owner);
                    }else if(action.equals("Cancel appointment")){
                        bookingDb.setStatus(id,"Cancelled","Your appointment with "+doctor+" on "+date+" at "+time+" was cancelled by the doctor. Please contact the hospital or book another slot.");
                        toast("Appointment cancelled. The patient will see the updated status in My Appointments.");
                        bookingDetails(id,true,owner);
                    }else if(action.equals("Suggest medicine / tablet")){
                        suggestMedicine(id,owner);
                    }else if(action.equals("Cancel appointment")){
                        bookingDb.setStatus(id,"Cancelled","You cancelled this appointment.");
                        toast("Appointment cancelled.");
                        showPatientBookings(owner);
                    }
                });
                box.addView(btn, bp);
            }
        }
        
        scroll.addView(box);
        
        new AlertDialog.Builder(this)
            .setTitle("Appointment #"+id+" ("+statusEmoji+")")
            .setView(scroll)
            .setPositiveButton("Close",null)
            .show();
    }
    private void suggestMedicine(long id,String doctor){LinearLayout box=new LinearLayout(this);box.setPadding(dp(20),0,dp(20),0);box.setOrientation(1);EditText med=field("Medicine / tablet name",InputType.TYPE_CLASS_TEXT),dose=field("Dosage (e.g. 1 tablet)",InputType.TYPE_CLASS_TEXT),freq=field("Frequency (e.g. twice daily)",InputType.TYPE_CLASS_TEXT),dur=field("Duration (e.g. 5 days)",InputType.TYPE_CLASS_TEXT),inst=field("Instructions",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);box.addView(med);box.addView(dose);box.addView(freq);box.addView(dur);box.addView(inst);new AlertDialog.Builder(this).setTitle("Doctor medicine suggestion").setMessage("Enter only the medicine prescribed/recommended after consultation.").setView(box).setPositiveButton("Save suggestion",(d,w)->{if(med.getText().toString().trim().isEmpty()){toast("Enter medicine name.");return;}bookingDb.saveMedicine(id,med.getText().toString().trim(),dose.getText().toString().trim(),freq.getText().toString().trim(),dur.getText().toString().trim(),inst.getText().toString().trim());toast("Medicine suggestion saved for this patient.");bookingDetails(id,true,doctor);}).setNegativeButton("Cancel",null).show();}

    private void findNearbyHospitals(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_PERMISSION_REQUEST);return;}try{LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);Location loc=null;try{loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);}catch(Exception ignored){}try{Location gps=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(gps!=null&&(loc==null||gps.getTime()>loc.getTime()))loc=gps;}catch(Exception ignored){}if(loc==null){startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));toast("Turn on location and tap Find Nearby Hospitals again.");return;}Intent map=new Intent(Intent.ACTION_VIEW,Uri.parse("geo:"+loc.getLatitude()+","+loc.getLongitude()+"?q=hospitals near "+loc.getLatitude()+","+loc.getLongitude()));try{map.setPackage("com.google.android.apps.maps");startActivity(map);}catch(Exception e){map.setPackage(null);startActivity(Intent.createChooser(map,"Find nearby hospitals"));}}catch(Exception e){toast("Unable to find location. Please enable GPS.");}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==LOCATION_PERMISSION_REQUEST){boolean ok=false;for(int x:g)if(x==PackageManager.PERMISSION_GRANTED)ok=true;if(ok)findNearbyHospitals();else toast("Location permission is required.");}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    private static class BookingDb extends SQLiteOpenHelper{
        BookingDb(Context c){super(c,"carepoint_bookings.db",null,4);}
        public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE IF NOT EXISTS patients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, phone TEXT NOT NULL UNIQUE, age TEXT, gender TEXT, password_hash TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, patient TEXT NOT NULL, phone TEXT NOT NULL, doctor TEXT NOT NULL, department TEXT NOT NULL, appointment_date TEXT NOT NULL, appointment_time TEXT NOT NULL, symptoms TEXT, booked_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending', medicine TEXT DEFAULT '', dosage TEXT DEFAULT '', frequency TEXT DEFAULT '', duration TEXT DEFAULT '', instructions TEXT DEFAULT '', notification TEXT DEFAULT 'Appointment request received. Waiting for doctor confirmation.')");db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS unique_doctor_slot ON bookings(doctor,appointment_date,appointment_time) WHERE status!='Cancelled' AND status!='Rejected'");db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS unique_patient_slot ON bookings(phone,appointment_date,appointment_time) WHERE status!='Cancelled' AND status!='Rejected'");}
        public void onUpgrade(SQLiteDatabase db,int old,int now){
            db.execSQL("CREATE TABLE IF NOT EXISTS patients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, phone TEXT NOT NULL UNIQUE, age TEXT, gender TEXT, password_hash TEXT NOT NULL)");
            db.execSQL("CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, patient TEXT NOT NULL, phone TEXT NOT NULL, doctor TEXT NOT NULL, department TEXT NOT NULL, appointment_date TEXT NOT NULL, appointment_time TEXT NOT NULL, symptoms TEXT, booked_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending', medicine TEXT DEFAULT '', dosage TEXT DEFAULT '', frequency TEXT DEFAULT '', duration TEXT DEFAULT '', instructions TEXT DEFAULT '', notification TEXT DEFAULT 'Appointment request received. Waiting for doctor confirmation.')");
            try{db.execSQL("ALTER TABLE bookings ADD COLUMN status TEXT NOT NULL DEFAULT 'Pending'");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE bookings ADD COLUMN medicine TEXT DEFAULT ''");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE bookings ADD COLUMN dosage TEXT DEFAULT ''");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE bookings ADD COLUMN frequency TEXT DEFAULT ''");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE bookings ADD COLUMN duration TEXT DEFAULT ''");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE bookings ADD COLUMN instructions TEXT DEFAULT ''");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE bookings ADD COLUMN notification TEXT DEFAULT 'Appointment request received. Waiting for doctor confirmation.'");}catch(Exception ignored){}
        }
        boolean registerPatient(String name,String email,String phone,String age,String gender,String hash){SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("name",name);v.put("email",email);v.put("phone",phone);v.put("age",age);v.put("gender",gender);v.put("password_hash",hash);return db.insertWithOnConflict("patients",null,v,SQLiteDatabase.CONFLICT_IGNORE)>0;}
        Cursor loginPatient(String email,String hash){return getReadableDatabase().query("patients",null,"email=? AND password_hash=?",new String[]{email,hash},null,null,null);}
        long addBooking(String p,String ph,String doc,String dept,String date,String time,String symptoms){SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("patient",p);v.put("phone",ph);v.put("doctor",doc);v.put("department",dept);v.put("appointment_date",date);v.put("appointment_time",time);v.put("symptoms",symptoms);v.put("booked_at",new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date()));v.put("status","Pending");return db.insertWithOnConflict("bookings",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
        boolean isSlotTaken(String doc,String date,String time){Cursor c=getReadableDatabase().rawQuery("SELECT id FROM bookings WHERE doctor=? AND appointment_date=? AND appointment_time=? AND status NOT IN ('Cancelled','Rejected') LIMIT 1",new String[]{doc,date,time});boolean yes=c.moveToFirst();c.close();return yes;}
        boolean isPatientSlotTaken(String phone,String date,String time){Cursor c=getReadableDatabase().rawQuery("SELECT id FROM bookings WHERE phone=? AND appointment_date=? AND appointment_time=? AND status NOT IN ('Cancelled','Rejected') LIMIT 1",new String[]{phone,date,time});boolean yes=c.moveToFirst();c.close();return yes;}
        Cursor getPatientBookings(String phone){return getReadableDatabase().query("bookings",null,"phone=?",new String[]{phone},null,null,"appointment_date,appointment_time");}
        Cursor getDoctorBookings(String doctor){return getReadableDatabase().query("bookings",null,"doctor=?",new String[]{doctor},null,null,"appointment_date,appointment_time");}
        Cursor getBooking(long id){return getReadableDatabase().query("bookings",null,"id=?",new String[]{String.valueOf(id)},null,null,null);}
        void setStatus(long id,String status,String notification){ContentValues v=new ContentValues();v.put("status",status);v.put("notification",notification);getWritableDatabase().update("bookings",v,"id=?",new String[]{String.valueOf(id)});}
        void saveMedicine(long id,String m,String d,String f,String du,String i){ContentValues v=new ContentValues();v.put("medicine",m);v.put("dosage",d);v.put("frequency",f);v.put("duration",du);v.put("instructions",i);v.put("notification","Your doctor has added a medicine suggestion for this appointment.");getWritableDatabase().update("bookings",v,"id=?",new String[]{String.valueOf(id)});}
    }
}
