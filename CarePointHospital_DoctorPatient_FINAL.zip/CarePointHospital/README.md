# CarePoint Hospital – Updated Android Java Project

Open the `CarePointHospital` folder in Android Studio, allow Gradle sync, and run the `app` configuration.

## Patient features
- Book by department or featured doctor, with patient name, phone, date, time and symptoms.
- Patient Login / My Appointments filters bookings by the phone number used during booking.
- View pending/confirmed/rejected/cancelled status and the doctor's saved message.
- View medicine/tablet suggestions, dosage, frequency, duration and instructions for that appointment.
- Cancel an active appointment.

## Doctor features
- Doctor Login lists the five sample doctor accounts. Demo password for each is `doctor123`.
- Each doctor sees only appointments assigned to their account.
- Confirm or reject pending appointments. The status and patient message are saved and visible in Patient Login / My Appointments.
- Add medicine/tablet suggestions to a specific appointment.

## Booking rules and limitations
- A doctor cannot have two active appointments for the same date and time, and a patient cannot book two appointments at the same date and time. A database unique index protects against duplicate simultaneous submissions; cancelled/rejected slots can be booked again.
- Department selection shows the doctor assigned to that department in this demo.
- Data is stored locally in SQLite on this device. This is a classroom/demo implementation, not a secure production login or a multi-phone cloud system. Patient access is identified by booking phone number; doctor accounts use a shared demo password.
- Confirmation messages are stored in the appointment and shown in the patient's appointment details. They are not SMS/push notifications. For real multi-device use, add secure authentication and a shared backend (e.g. Firebase or REST API) and push notifications.

## Nearby hospitals
Tap Find Nearby Hospitals, grant location permission, and enable GPS. The app opens a nearby-hospital search in Google Maps based on the phone's current location.
\n\n## Patient registration and login (updated)\n\nPatients must register before booking. Registration collects full name, email, mobile number, age, gender, and password. Email and mobile number must be unique; passwords are stored as SHA-256 hashes in the local SQLite database. After registration, the patient is logged in automatically. Existing patients log in with email and password and can view their appointments. Booking from a doctor card or department requires a logged-in patient and uses the registered name and mobile number. Doctor accounts remain admin-provided demo accounts; each listed doctor uses the demo password `doctor123`.\n

## Appointment approval workflow update
- Doctors can view bookings assigned to their selected doctor account.
- Pending bookings can be confirmed or cancelled by the doctor.
- Confirmed bookings can also be cancelled by the doctor.
- Patients can open **My Appointments** to see Pending, Confirmed, or Cancelled status and the latest doctor message.
- Patients can cancel their own bookings.
- Medicine suggestions entered by the doctor are shown in the patient's appointment details.

**Storage note:** This project uses on-device SQLite. Patient and doctor status updates are visible when both roles use the same app database on the same device. For different phones to share live appointments, the project needs a cloud backend such as Firebase or a hosted API.
